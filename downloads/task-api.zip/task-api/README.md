# Kleeman Spring Boot guide — Task API

A complete **local learning** project for Java 21 and Spring Boot 4.1.1.

## Requirements and run

Install JDK 21 and Maven 3.6.3 or later. Verify `java -version`, `javac -version`, and `mvn -v` use the right JDK. Internet access is needed for dependency downloads.

In this folder (the one containing pom.xml):

```sh
mvn verify
mvn spring-boot:run
```

Stop with Ctrl+C. Alternatively: `java -jar target/task-api-0.0.1-SNAPSHOT.jar` after verification. This download does not include a Maven wrapper. You may copy these sources and pom.xml into your Initializr project and keep its wrapper, then use `./mvnw` on macOS/Linux or `.\mvnw.cmd` on Windows instead of `mvn`.

The server binds to your own computer at port 8080. Try http://localhost:8080/hello?name=Matthew . There is no endpoint at `/`, so 404 there is normal.

## Windows PowerShell walkthrough

```powershell
$task = Invoke-RestMethod -Method Post -Uri http://localhost:8080/api/tasks -ContentType 'application/json' -Body '{"title":"Learn Spring"}'
$task
Invoke-RestMethod -Uri "http://localhost:8080/api/tasks/$($task.id)"
Invoke-RestMethod -Method Put -Uri "http://localhost:8080/api/tasks/$($task.id)" -ContentType 'application/json' -Body '{"title":"Learn Spring","completed":true}'
Invoke-RestMethod -Method Delete -Uri "http://localhost:8080/api/tasks/$($task.id)"
```

After deletion GET for that ID returns 404, which PowerShell reports as an error.

## macOS / Linux

```sh
curl -i -X POST http://localhost:8080/api/tasks -H 'Content-Type: application/json' -d '{"title":"Learn Spring"}'
```

Copy the returned ID. Use GET `/api/tasks/{id}`, PUT the JSON `{"title":"Learn Spring","completed":true}` to that URL, and DELETE it. Creation returns 201 and a Location header; update returns 200; delete returns 204; missing records return 404; validation or malformed JSON returns 400. GET `/api/tasks` returns the list ordered by ID.

## Project map

- TaskController: HTTP mappings and statuses.
- TaskService: use cases, transaction boundaries, entity-to-DTO mapping.
- TaskRepository: Spring Data JPA interface.
- Task: persistence model.
- CreateTaskRequest, UpdateTaskRequest, TaskResponse: API messages.
- ApiErrors: structured problem details.
- TaskTest: a plain unit test.
- TaskApiIntegrationTest: real HTTP lifecycle and bad-input tests on a random port.

## Scope and next steps

H2 is in memory and create-drop destroys data on restart. No authentication, per-user ownership, pagination, migrations, or production deployment is included. Do not expose this as a multi-user service. Follow the security, pagination, and production lessons before deploying a real backend. `findByCompleted` is an example repository query, not a connected API filter.

Java compilation and tests were not executed while this guide was published; run `mvn verify` locally. The website is a reading guide, not a Java runtime.
