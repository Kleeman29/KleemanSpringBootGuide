package com.example.taskapi;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class TaskTest {
    @Test void aNewTaskIsIncompleteAndCanBeUpdated() {
        Task task = new Task("Study");
        assertFalse(task.isCompleted());
        task.update("Study Spring", true);
        assertEquals("Study Spring", task.getTitle());
        assertTrue(task.isCompleted());
    }
}
