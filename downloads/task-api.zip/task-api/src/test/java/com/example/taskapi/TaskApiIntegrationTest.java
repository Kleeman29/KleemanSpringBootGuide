package com.example.taskapi;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class TaskApiIntegrationTest {
    @LocalServerPort int port;
    private final HttpClient client = HttpClient.newHttpClient();
    private HttpResponse<String> request(String method, String path, String json) throws Exception {
        var builder = HttpRequest.newBuilder(URI.create("http://localhost:" + port + path));
        if (json == null) builder.method(method, HttpRequest.BodyPublishers.noBody());
        else builder.header("Content-Type", "application/json")
            .method(method, HttpRequest.BodyPublishers.ofString(json));
        return client.send(builder.build(), HttpResponse.BodyHandlers.ofString());
    }
    @Test void taskLifecycle() throws Exception {
        var created = request("POST", "/api/tasks", "{\"title\":\"Learn Spring\"}");
        assertEquals(201, created.statusCode());
        String path = created.headers().firstValue("Location").orElseThrow();
        var fetched = request("GET", path, null);
        assertEquals(200, fetched.statusCode());
        assertTrue(fetched.body().contains("Learn Spring"));
        var updated = request("PUT", path, "{\"title\":\"Finished\",\"completed\":true}");
        assertEquals(200, updated.statusCode());
        assertTrue(request("GET", path, null).body().contains("Finished"));
        var deleted = request("DELETE", path, null);
        assertEquals(204, deleted.statusCode());
        assertTrue(deleted.body().isEmpty());
        assertEquals(404, request("GET", path, null).statusCode());
    }
    @Test void rejectsBadInput() throws Exception {
        var blank = request("POST", "/api/tasks", "{\"title\":\"   \"}");
        assertEquals(400, blank.statusCode());
        assertTrue(blank.body().contains("Title is required"));
        assertEquals(400, request("POST", "/api/tasks", "{").statusCode());
        assertEquals(400, request("GET", "/api/tasks/abc", null).statusCode());
        assertEquals(400, request("PUT", "/api/tasks/1", "{\"title\":\"Missing completion\"}").statusCode());
    }
}
