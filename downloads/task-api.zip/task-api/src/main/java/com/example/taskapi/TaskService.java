package com.example.taskapi;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@Transactional(readOnly = true)
public class TaskService {
    private final TaskRepository repository;
    public TaskService(TaskRepository repository) { this.repository = repository; }
    public List<TaskResponse> list() {
        return repository.findAll(org.springframework.data.domain.Sort.by("id"))
            .stream().map(this::response).toList();
    }
    public TaskResponse get(Long id) { return response(require(id)); }
    @Transactional
    public TaskResponse create(CreateTaskRequest request) {
        return response(repository.save(new Task(request.title())));
    }
    @Transactional
    public TaskResponse update(Long id, UpdateTaskRequest request) {
        Task task = require(id);
        task.update(request.title(), request.completed());
        return response(task);
    }
    @Transactional
    public void delete(Long id) { repository.delete(require(id)); }
    private Task require(Long id) {
        return repository.findById(id).orElseThrow(() -> new TaskNotFoundException(id));
    }
    private TaskResponse response(Task task) {
        return new TaskResponse(task.getId(), task.getTitle(), task.isCompleted());
    }
}
