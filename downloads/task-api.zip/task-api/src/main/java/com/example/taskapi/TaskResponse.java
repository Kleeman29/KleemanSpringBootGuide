package com.example.taskapi;
public record TaskResponse(Long id, String title, boolean completed) {}
