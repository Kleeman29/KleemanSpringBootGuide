package com.example.taskapi;
import org.springframework.web.bind.annotation.*;
@RestController
public class HelloController {
    public record Greeting(String message) {}
    @GetMapping("/hello")
    public Greeting hello(@RequestParam(defaultValue = "World") String name) {
        return new Greeting("Hello, " + name + "!");
    }
}
